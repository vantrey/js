import React from 'react';
import './Tolkachev.css'
class Tolkachev extends React.Component {
    render = () => {
        return (
                <div className="tolkachev">
                    Толкачёв Иван Борисович
                </div>
        );
    }
}
export default Tolkachev;

